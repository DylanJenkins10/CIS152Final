/**
 * 
 */
module CIS152Final {
	requires java.desktop;
}